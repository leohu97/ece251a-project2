#ifndef BLINKY_H_
#define BLINKY_H_
//#include "blinky.asm"
#include <SI_EFM8BB3_Register_Enums.h>
extern void c_blinky(void);

#endif /* BLINKY_H_ */
